
    java -jar -Xmx256m UniversalGcodeSender-linux32.jar
        