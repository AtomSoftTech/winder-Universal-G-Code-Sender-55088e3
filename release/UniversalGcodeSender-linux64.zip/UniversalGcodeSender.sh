
    java -jar -Xmx256m UniversalGcodeSender-linux64.jar
        